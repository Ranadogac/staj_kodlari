const express = require('express');
const http = require('http');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server);
app.use(express.static(__dirname));

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});

io.on('connection', (socket) => {
  console.log('Bir kullanıcı bağlandı');
  socket.on('mesaj_gonder', (data) => {
    io.emit('mesaj_al', data);
  });

  socket.on('disconnect', () => {
    console.log('Bir kullanıcı ayrıldı');
  });
});

server.listen(3000, () => {
  console.log('Sunucu 3000 portunda çalışıyor...');
});