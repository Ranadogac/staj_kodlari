const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const PORT = 3000;
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.use(express.static(path.join(__dirname)));
const mongoURI = "mongodb+srv://dogacrana_db:Rana346500@cluster0.nocagtx.mongodb.net/?appName=Cluster0";
mongoose.connect(mongoURI)
    .then(() => console.log(" MongoDB Atlas veritabanına başarıyla bağlandık!"))
    .catch(err => console.error(" Veritabanı bağlantı hatası:", err));
const SatirSchema = new mongoose.Schema({
    tarih: String,
    kimden: String,
    fis_turu: String,
    tutar: Number
});
const FormSchema = new mongoose.Schema({
    form_no: { type: String, required: true },
    satirlar: [SatirSchema] 
});
const Form = mongoose.model('Form', FormSchema);
app.post('/kaydet', async (req, res) => {
    try {
        const { form_numarasi, tarih, kimden, fis_turu, tutar } = req.body;
        let formatliSatirlar = [];
        if (tarih && Array.isArray(tarih)) {
            for (let i = 0; i < tarih.length; i++) {
                if (tarih[i] || kimden[i] || tutar[i]) {
                    formatliSatirlar.push({
                        tarih: tarih[i],
                        kimden: kimden[i],
                        fis_turu: fis_turu[i],
                        tutar: parseFloat(tutar[i]) || 0
                    });
                }
            }
        }
        const yeniForm = new Form({
            form_no: form_numarasi,
            satirlar: formatliSatirlar
        });

        await yeniForm.save();
        
        res.send("<h2> Veriler MongoDB Atlas veritabanına başarıyla kaydedildi!</h2><a href='/'>Geri Dön</a>");

    } catch (error) {
        console.error(error);
        res.status(500).send("Veri kaydedilirken backend tarafında bir hata oluştu.");
    }
});

app.listen(PORT, () => {
    console.log(`🌍 Sunucu http://localhost:${PORT} adresinde çalışıyor!`);
});