-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Anamakine: localhost
-- Üretim Zamanı: 09 Tem 2026, 14:03:08
-- Sunucu sürümü: 10.4.28-MariaDB
-- PHP Sürümü: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `vergi_sistemi`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `formlar`
--

CREATE TABLE `formlar` (
  `id` int(11) NOT NULL,
  `form_no` varchar(50) NOT NULL,
  `kayit_tarihi` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `formlar`
--

INSERT INTO `formlar` (`id`, `form_no`, `kayit_tarihi`) VALUES
(1, 'FRM-101', '2026-07-09 11:57:28');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `form_satirlari`
--

CREATE TABLE `form_satirlari` (
  `id` int(11) NOT NULL,
  `form_id` int(11) NOT NULL,
  `sira_no` int(11) NOT NULL,
  `tarih` date DEFAULT NULL,
  `kimden` varchar(255) DEFAULT NULL,
  `fis_turu` varchar(50) DEFAULT NULL,
  `tutar` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `form_satirlari`
--

INSERT INTO `form_satirlari` (`id`, `form_id`, `sira_no`, `tarih`, `kimden`, `fis_turu`, `tutar`) VALUES
(1, 1, 1, '2026-05-12', 'ASLAN DOĞAÇ', 'egitim', 12000.00),
(2, 1, 2, '2005-01-25', 'RANA DOĞAÇ', 'akaryakit', 300.00);

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `formlar`
--
ALTER TABLE `formlar`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `form_satirlari`
--
ALTER TABLE `form_satirlari`
  ADD PRIMARY KEY (`id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `formlar`
--
ALTER TABLE `formlar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Tablo için AUTO_INCREMENT değeri `form_satirlari`
--
ALTER TABLE `form_satirlari`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
