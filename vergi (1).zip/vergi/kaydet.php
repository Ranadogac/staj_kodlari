<?php
// 1. HATALARI EKRANA BASMA (500 hatası yerine hatanın ne olduğunu okuyabilmek için)
ini_set('display_errors', 1);
ini_set('display_errors', 'On');
error_reporting(E_ALL);

// 2. VERİTABANI BAĞLANTISI (Mac XAMPP uyumlu local bağlantı)
try {
    // Mac XAMPP için senin bilgisayarında çalışan 3307 portunu sabitledik
    $db = new PDO("mysql:host=127.0.0.1;port=3307;dbname=vergi_sistemi;charset=utf8", "root", "");
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Veritabanı bağlantısı başarısız oldu: " . $e->getMessage());
}

// 3. FORMDAN VERİ GELDİ Mİ KONTROLÜ
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // Form numarasını kontrol ederek alıyoruz
    $formNo = isset($_POST['form_numarasi']) ? $_POST['form_numarasi'] : 'Belirtilmedi';

    // Ana form tablosuna kayıt
    $formEkle = $db->prepare("INSERT INTO formlar (form_no) VALUES (?)");
    $formEkle->execute([$formNo]);
    
    $yeniFormId = $db->lastInsertId();

    // Dizileri yakalama
    $tarihler = isset($_POST['tarih']) ? $_POST['tarih'] : [];
    $kimdenAlindi = isset($_POST['kimden']) ? $_POST['kimden'] : [];
    $fisTurleri = isset($_POST['fis_turu']) ? $_POST['fis_turu'] : [];
    $tutarlar = isset($_POST['tutar']) ? $_POST['tutar'] : [];

    // Döngü ile tüm satırları parse edip yazma
    for ($i = 0; $i < count($tutarlar); $i++) {
        
        $siraNo = $i + 1;
        $satirTarih = !empty($tarihler[$i]) ? $tarihler[$i] : null;
        $satirKimden = !empty($kimdenAlindi[$i]) ? $kimdenAlindi[$i] : '';
        $satirTur = !empty($fisTurleri[$i]) ? $fisTurleri[$i] : '';
        $satirTutar = !empty($tutarlar[$i]) ? $tutarlar[$i] : 0;

        // Tutar kontrolü
        if ($satirTutar == "" || is_null($satirTutar)) {
            $satirTutar = 0;
        }
        
        // Boş satırları filtreleyen alan
        if (!empty($satirTarih) || $satirTutar > 0) {
            $satirEkle = $db->prepare("INSERT INTO form_satirlari (form_id, sira_no, tarih, kimden, fis_turu, tutar) VALUES (?, ?, ?, ?, ?, ?)");
            $satirEkle->execute([$yeniFormId, $siraNo, $satirTarih, $satirKimden, $satirTur, $satirTutar]);
        }
    } // For döngüsü bitişi

    // Başarılı yönlendirme (Artık IF bloğunun içinde, doğru yerde)
    echo "<script>
            alert('Form Başarıyla Oluşturuldu! " . $formNo . " numaralı form ve doldurulan satırlar kaydedildi.');
            window.location.href = 'index.html';
          </script>";

} // POST If bloğu bitişi
?>
